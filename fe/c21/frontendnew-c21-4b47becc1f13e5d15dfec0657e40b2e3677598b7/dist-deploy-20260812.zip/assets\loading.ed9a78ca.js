import{m as a}from"./arco.01d144c4.js";function l(e=!1){const o=a(e);return{loading:o,setLoading:t=>{o.value=t},toggle:()=>{o.value=!o.value}}}export{l as u};
