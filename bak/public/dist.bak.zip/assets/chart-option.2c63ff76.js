import{c as t}from"./arco.1d6419e8.js";import{b as a}from"./index.a79af243.js";function c(r){const o=a(),e=t(()=>o.theme==="dark");return{chartOption:t(()=>r(e.value))}}export{c as u};
