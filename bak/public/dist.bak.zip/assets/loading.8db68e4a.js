import{g as t}from"./arco.1d6419e8.js";function l(e=!1){const o=t(e);return{loading:o,setLoading:a=>{o.value=a},toggle:()=>{o.value=!o.value}}}export{l as u};
